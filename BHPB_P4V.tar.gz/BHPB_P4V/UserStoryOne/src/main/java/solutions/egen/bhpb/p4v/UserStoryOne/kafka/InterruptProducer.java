package solutions.egen.bhpb.p4v.UserStoryOne.kafka;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

import solutions.egen.bhpb.UserStoryOne.InterruptInfo.InterruptProto;
import solutions.egen.bhpb.UserStoryOne.InterruptInfo.InterruptProto.Interrupt;

public class InterruptProducer {

	private Producer<String, byte[]>	kafkaTrain;
	private InputStream					inputStream;
	private Properties					kafkaProperties;

	private static byte[] generateInterrupt() {
		InterruptProto.Builder iBuilder = InterruptProto.newBuilder();
		Interrupt.Builder interruptBuilder = Interrupt.newBuilder();

		interruptBuilder.setEquipmentId("EX1234");
		interruptBuilder.setInterruptType("EF");
		interruptBuilder.setFailureType("Hydraulic Failure");
		interruptBuilder.setHumanError(false);
		interruptBuilder.setNewEvent(false);

		iBuilder.setInterrupt(interruptBuilder.build());
		iBuilder.setNotes("This is a test packet");
		iBuilder.setSiteId(4563);
		iBuilder.setSenderId("RepStationId1235");

		return iBuilder.build().toByteArray();
	}

	public InterruptProducer(KafkaShipmentBuilder kafkaShipmentBuilder) {
		/*
		 * Set up Kafka producer
		 */
		try {
			inputStream = new FileInputStream(kafkaShipmentBuilder.propertyFileLocation);
			kafkaProperties = new Properties();
			kafkaProperties.load(inputStream);
			kafkaProperties.put("sourceTopic", kafkaShipmentBuilder.sourceTopic);
			kafkaTrain = new Producer<String, byte[]>(new ProducerConfig(kafkaProperties));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendMessage() throws InterruptedException {
		for (int i = 0; i < 1000; i++) {
			byte[] outputKafkaBytes = generateInterrupt();
			kafkaTrain.send(
					new KeyedMessage<String, byte[]>(kafkaProperties.getProperty("sourceTopic"), outputKafkaBytes));
			System.out.println(" Sending canned interrupt messages to " + kafkaProperties.getProperty("sourceTopic"));
			Thread.sleep(1500l);
		}
	}

	public void cleanUp() throws IOException {
		this.inputStream.close();
		this.kafkaTrain.close();
	}

	public static class KafkaShipmentBuilder {
		private String	sourceTopic;
		private String	propertyFileLocation;

		public KafkaShipmentBuilder withPropertyFileAt(String fileLocation) {
			this.propertyFileLocation = fileLocation;
			return this;
		}

		public KafkaShipmentBuilder withSourceTopic(String sourceTopic) {
			this.sourceTopic = sourceTopic;
			return this;
		}

		public KafkaShipmentBuilder build() throws Exception {
			return new KafkaShipmentBuilder();
		}
	}

}
