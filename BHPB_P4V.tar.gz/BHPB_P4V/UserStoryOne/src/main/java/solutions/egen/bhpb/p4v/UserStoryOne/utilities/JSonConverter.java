package solutions.egen.bhpb.p4v.UserStoryOne.utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import solutions.egen.bhpb.UserStoryOne.GanttInfo;
import solutions.egen.bhpb.UserStoryOne.GanttInfo.GanttPacket;

public class JSonConverter {

	/**
	 * Useful cheat sheet info | JSON | Java | |:---------|:---------| | string
	 * | java.lang.String | | number | java.lang.Number | | true|false |
	 * java.lang.Boolean | | null | null | | array | java.util.List | | object |
	 * java.util.Map |
	 */
	
	private JSONParser jsonParser;
	private JSONObject jsonObject;
	
	public JSonConverter(String fileLoc){
		jsonParser = new JSONParser();
		try {
			Object object = jsonParser.parse(new FileReader(fileLoc));
			jsonObject = (JSONObject) object;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public JSonConverter(File jsonSource) {
		jsonParser = new JSONParser();
		try {
			Object object = jsonParser.parse(new FileReader(jsonSource));
			jsonObject = (JSONObject) object;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public GanttPacket convertToProto(){
		GanttPacket.Builder gBuilder = GanttPacket.newBuilder();
		return gBuilder.build();
	}
	
	public JSONObject getJSonObject(){
		return jsonObject;
	}
}
