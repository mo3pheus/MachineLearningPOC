package solutions.egen.bhpb.p4v.UserStoryOne;

import solutions.egen.bhpb.p4v.UserStoryOne.utilities.JSonConverter;

public class JSonConversionTest {
	public static void main(String[] args) {
		/*
		 * JSonConverter jConverter = new JSonConverter(
		 * JSonConversionTest.class.getClassLoader().getResource(
		 * "expected-gantt-chart.json").toString());
		 */
		JSonConverter jConverter = new JSonConverter(
				"//home//sanket//Documents//Code//MyProjects//Java//MavenProjects//codingGym//BHPB_P4V//UserStoryOne//src//main//resources//expected-gantt-chart.json");

		System.out.println(jConverter.getJSonObject().toJSONString());
	}
}
